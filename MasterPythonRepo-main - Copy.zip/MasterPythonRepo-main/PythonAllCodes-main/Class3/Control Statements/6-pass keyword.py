#>>> while True:
#...     pass  # Busy-wait for keyboard interrupt (Ctrl+C)
#...


#>>> class MyEmptyClass:
#...     pass
#...

def fun():
   pass

fun()

#  this function takes 2 parameters and adds them
def add(a,b):
   """Information about this code or function"""
   c= a+b
   pass
   print("Addition is ", c)
   return c
print(add.__doc__)
result = add(11,2)
print("value of result is ", result)


def add():
   pass


   




