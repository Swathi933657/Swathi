try:
    x = int(input("Enter number: "))
except:
    print("Invalid input")
finally:
    print("Execution finished")
