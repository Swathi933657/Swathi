temp = set({})
print(temp)
temp2 = {1,2,343,"Suraj",'xyz',1,2}
print(temp2)

#actions 



#hetro or homo data type 
#insertion 
#duluplicates
#null
#can be chnanged 
print("Before using clear ",temp2)
temp2.clear()
print("after using clear ",temp2)
temp2.discard()
temp2.remove()


# leanring curve
#creation,accessing,traversing ,funtions verbs ,difference in verbs 
#membership, nested,comphreshion 