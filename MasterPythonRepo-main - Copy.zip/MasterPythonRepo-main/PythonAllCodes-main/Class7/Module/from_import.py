# from ... import
from math import sqrt, pi
print(sqrt(25), pi)
