


# def add():
#     pass

# add()





# def add():
#     c=1+2
#     print(c)
# add()


# def add(a,b):
#     c=a+b
#     print(c)

# add(23,4)

print("helow ")
result = Math.sqrt(36)



def add(a=90,b=1):
   c=a+b
   print(c)
   return c

add(3,2)


