print("Different data types for Python")
print("")
# add code to demo al data types
# int, float, str, bool and complex data types  in python  (list ,set,tuple,dictionary)           

a = 5
b = 3.14
c = "Hello"
d = True
e = 1 + 2j
f = [1, 2, 3]
g = (4, 5, 6)
h = {7, 8, 9}
i = {"key": "value"}
print(type(a))              
print(type(b))
print(type(c))
print(type(d))




age = "hi"
b = False
a=90
# a="suraj
print("value of a is ", a)
print(type(age))

a = 89

b = 454545454


c = 34.56656565

print("value of b is " + str(b))
print (type(c))
