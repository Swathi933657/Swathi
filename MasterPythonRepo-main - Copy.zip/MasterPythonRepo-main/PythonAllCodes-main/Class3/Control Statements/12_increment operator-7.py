a=12
print(a)

a+=1
print(a)
a-=1

print(a)


#++ operator is not available in python
#you can  do a=a+1;
#All namespace modification in Python is a statement, for simplicity and consistency.
