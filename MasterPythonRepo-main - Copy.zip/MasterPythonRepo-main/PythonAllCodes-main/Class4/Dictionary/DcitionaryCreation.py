d1 = {}
d2 = dict()
d3 = {'name': 'Alice'}
d4 = dict(zip(['a', 'b'], [1, 2]))
d5 = {x: x**2 for x in range(3)}
# print(d1)
# print(d2)
# print(d3)
# print(d4)
print(d5)