# Renaming a Module at the time of import (Module Aliasing)
import math as m
print(m.sqrt(16))
