# else Block with try-except-finally
try:
    x = 10
except:
    print("Except")
else:
    print("Else block")
finally:
    print("Finally block")
