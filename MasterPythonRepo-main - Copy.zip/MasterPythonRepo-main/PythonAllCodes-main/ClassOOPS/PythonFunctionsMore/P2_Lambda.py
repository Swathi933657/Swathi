# Lambda is a small anonymous function
nameOFFunction = lambda print("somemthing ")



print(nameOFFunction(6))  # Output: 25
