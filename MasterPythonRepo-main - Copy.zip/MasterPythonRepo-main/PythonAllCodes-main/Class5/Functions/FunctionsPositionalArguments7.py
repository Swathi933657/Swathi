# Positional Arguments - 6 Examples

# Example 1
def user_info(name, age):
    print(name, age)

user_info("Alice", 25)

# Example 2
def area(length, breadth):
    return length * breadth

print(area(10, 5))

# Exampl
