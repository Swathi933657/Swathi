
# ascii()
# print(ascii("hello"))
# print(ascii("hëllö"))
# print(ascii("€"))
# print(ascii("\nTab"))
# print(ascii("😊"))

#code which uses ascii in real life scenario
# user_input = input("Enter a string: ")
# print("ASCII representation:", ascii(user_input))

#more code examples using ascii()
# file_name = "data_€_2024.txt"  non ascii character 
# safe_file_name = ascii(file_name)
# print("Original file name:", file_name)



#code to print Heloow World
print("Hello, World!")  
print("Hello, Python!")
print("Welcome to programming!")
print("Let's code together!")


# bin()
print(bin(5))
print(bin(10))
print(bin(255))
print(bin(0))
print(bin(1024))

# # ord()
print(ord('A'))
print(ord('a'))
print(ord('@'))
print(ord('€'))
print(ord('\n'))

# Convert a decimal number to hexadecimal
print(hex(255))  # Output: '0xff'
print(hex(16))   # Output: '0x10'

#code to add two numbers 
a = 5
b = 10
sum = a + b
print("The sum of", a, "and", b, "is", sum) 
#code to find the maximum of two numbers
x = 15  
y = 20
maximum = max(x, y)

