a=90
#code is sqauring the number 
def square(n):
    """ This function suare the input and  returns the same square """
    
    return n * n

# print("Square of 5 is", square(5))
# print("Square of 9 is", square(9))
print(square.__doc__)


#TODO
#keyword Argument 









