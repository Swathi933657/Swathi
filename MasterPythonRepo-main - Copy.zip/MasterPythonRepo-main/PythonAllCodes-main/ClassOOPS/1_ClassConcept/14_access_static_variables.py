# How to access Static Variables
class Student:
    city = "Hyderabad"
print(Student.city)
