try:
    int("xyz")
except Exception as e:
    print("Caught Exception:", e)
