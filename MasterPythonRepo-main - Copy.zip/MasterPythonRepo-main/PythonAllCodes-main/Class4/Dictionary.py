d = {"key1": "Value1", "Key2": "Value2", "Key3": "Value3"}

print(d)
d["Key1"]
