Mohan = [3, 1, 4]
Mohan.append(5)
print("After append ",Mohan)
Mohan.insert(2, 24)
print("After Insert ",Mohan)


Mohan.remove(4)
print("After remove ",Mohan)
Mohan.sort()
print("After sort ",Mohan)
Mohan.pop()  #has return type too
print("After pop ",Mohan)
#using index in pop
Mohan.pop()
print("After one more pop ",Mohan)
Mohan.clear()
print("After clear ",Mohan)

a= (1,2,3,4,"suraj")
print(a)

#TODO
#reverse ,sort ,reverse default sorting order etc
Mohan.rever

#TODO
#add a new file on copy of list ..using slicing and copy 

#TODO 
#Nested List and Matrix concept 