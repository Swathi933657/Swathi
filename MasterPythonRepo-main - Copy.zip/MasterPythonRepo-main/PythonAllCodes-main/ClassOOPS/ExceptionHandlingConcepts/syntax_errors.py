# Syntax Errors
# print("Hello"  # SyntaxError: missing closing parenthesis
