name = "John"
height = 5.9
age = 28

print("Name: %s, Age: %d, Height: %.1f ft" % (name, age, height))
# Output: Name: John, Age: 28, Height: 5.9 ft
