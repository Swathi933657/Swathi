try:
    import abcdefg
except ModuleNotFoundError:
    print("ModuleNotFoundError occurred")
