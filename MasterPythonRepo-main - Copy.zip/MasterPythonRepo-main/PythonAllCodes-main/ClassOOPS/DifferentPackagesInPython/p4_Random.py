import random

print(random.randint(1, 10))           # Integer
print(random.choice(['a', 'b', 'c']))  # Random element
print(random.random())                 # 0.0 to 1.0
random.shuffle([1, 2, 3, 4])
