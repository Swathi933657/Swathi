


def changefunc(parameter):
    myname="suraj2222"
    print("i am inside the function")
    print(myname)


myname="suraj"
print(myname)
print("i am outside th sunction0")
changefunc(myname)
print("the end")
