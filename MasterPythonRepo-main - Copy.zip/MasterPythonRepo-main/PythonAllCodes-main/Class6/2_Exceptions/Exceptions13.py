try:
    print(10 / 2)
finally:
    print("This runs always")
