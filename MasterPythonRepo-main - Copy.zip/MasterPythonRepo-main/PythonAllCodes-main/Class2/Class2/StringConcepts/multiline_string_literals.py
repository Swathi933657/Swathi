multi_line = """This is
a multi-line
string."""
print(multi_line)