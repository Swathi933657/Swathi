import pdb

def calculate():
    a = 5
    b = 10
    pdb.set_trace()  # Debug from here
    print(a + b)

calculate()
