import array

print("Array homogenious Data Type")

# Creation of array
arrayNormal = [1, 2, 156]

# with array object from Standard Python Lib
# a=array(data type,value list)


# Getting Length of any array
print(len(arrayNormal))

# printing the array
print(arrayNormal)

# accessign the elements in array
print(arrayNormal)
# deleting the array
del arrayNormal[2]

print(arrayNormal)

del arrayNormal
print(arrayNormal)
