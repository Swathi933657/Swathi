# Reordering using indexes in .format()
print("Second: {1}, First: {0}".format("Apple", "Banana"))
# Output: Second: Banana, First: Apple
