import math

print(math.sqrt(36))

print(math.ceil(9.455445))
print(math.floor(9.455445))
print("you can check for other predefined functions ")



