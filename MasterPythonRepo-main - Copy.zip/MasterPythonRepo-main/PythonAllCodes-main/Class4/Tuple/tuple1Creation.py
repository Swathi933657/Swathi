#add all theory for list page 117 in hard copy 
#Use the pic .. insertion order, immutablilty , duplicate,none 
#Different ways to create tuple 
#t = 10,12,13   how it detects its tuple 
t1 = ()

t2 = (1,)
t3 = (1, 2, 3)
t4 = tuple('abc')
t5 = tuple([1, 2, 3])
t7=(10,)  #mandatory to end with comma for single tuple 


temp = (1,2,"aunp",1,2,"anup",1,2,"anup",1,2,"anup")
print(temp)

