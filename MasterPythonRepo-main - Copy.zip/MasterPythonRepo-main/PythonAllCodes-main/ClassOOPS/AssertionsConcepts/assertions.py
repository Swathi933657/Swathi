# Assertions
x = 5
assert x > 0, "x should be positive"


#add more example code below



