# What is Object?
# An object is an instance of a class.

class Person:
    pass

obj1 = Person()

class Student:
    pass
nikshan = Student()

class Automobile:
    tires="tires"   #//2 bytes
    def func():   #// 7 Bytes
        a=90  #// 1byte
        print("")

BMW = Automobile()  # 10 bytes
print(BMW.tires)
BMW.func()
Thar = Automobile()  #bytes
Hummer = Automobile()
Audi = Automobile()
