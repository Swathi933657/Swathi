# Python program to demonstrate working
# of map.


# Return double of n
def addition(n):
    return n + n


# Return subtraction  of n
def subtraction(n):
    return n - n


# We double all numbers using map()
numbers = (1, 2, 3, 4)
result = map(addition, numbers)
print(list(result))


result = map(subtraction, numbers)
print(list(result))
