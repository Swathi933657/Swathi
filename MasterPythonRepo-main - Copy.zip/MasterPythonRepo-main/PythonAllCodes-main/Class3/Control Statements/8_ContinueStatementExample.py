for i in range(10):
    if i == 3:
        continue  # Exit the loop when i is 3
    print("i:", i)

# Output:
# i: 0
# i: 1
# i: 2
