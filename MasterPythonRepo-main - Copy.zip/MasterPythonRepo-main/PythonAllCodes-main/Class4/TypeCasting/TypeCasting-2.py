name = "Alice"
age = 30

print("Name: %s, Age: %d" % (name, age))
# Output: Name: Alice, Age: 30

pi = 3.14159
print("Value of pi: %.2f" % pi)
# Output: Value of pi: 3.14
