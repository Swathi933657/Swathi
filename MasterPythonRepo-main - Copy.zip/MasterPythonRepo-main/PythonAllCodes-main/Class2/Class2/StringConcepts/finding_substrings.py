s = "Python programming"
print(s.find("gram"))   # 10
print(s.find("xyz"))    # -1