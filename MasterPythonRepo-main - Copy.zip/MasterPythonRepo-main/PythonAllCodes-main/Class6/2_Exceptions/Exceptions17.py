try:
    {}["key"]
except KeyError:
    print("KeyError occurred")
