#!/usr/bin/python

# Function definition is here
def justprint( str ):
   "This prints a passed string into this function"
   print (str);
   return;

# Now you can call printme function
justprint("I'm first String to user defined function!");
justprint("Again second String2 to the same function");
