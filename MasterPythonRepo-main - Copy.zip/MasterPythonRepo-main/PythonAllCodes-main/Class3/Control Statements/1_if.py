 
i=20
if i == 19:
        a=90
        print("Value:",i)
        print("Value of a:",a)
elif i == 20:
        print("I will be executed if i is equal to 20")
else:
        print("I will be executed if i is not equal to 19 or 20")


print("I am end ")

# for i in range(2):     
#     print("Value: of i is", i)

#     # 0 --Value: of i is 0
#     # 1--- Value: of i is 1
#     # 2- Value: of i is 2
     
     

# # Output:
# # Value: 0
# # Value: 1
# # Value: 2
# # Value: 3
# # Value: 4
