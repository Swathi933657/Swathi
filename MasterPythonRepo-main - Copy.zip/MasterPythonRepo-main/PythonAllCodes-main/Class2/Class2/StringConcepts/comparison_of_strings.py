a = "apple"
b = "banana"
print(a == b)   # False
print(a < b)    # True (lexicographical)