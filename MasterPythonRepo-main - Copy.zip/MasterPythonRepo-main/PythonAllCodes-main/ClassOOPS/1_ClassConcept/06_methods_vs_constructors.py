# Differences between Methods and Constructors
class Test:
    def __init__(self):
        print("Constructor")
    def show(self):
        print("Method")


t = Test()
t.show()
