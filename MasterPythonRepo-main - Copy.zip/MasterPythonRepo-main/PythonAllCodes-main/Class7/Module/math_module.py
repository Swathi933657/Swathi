# Working with math Module
import math
print(math.factorial(5))
print(math.pow(2, 3))
print(math.ceil(2.3))
