import operator

print(operator.add(3, 4))   # 7
print(operator.mul(3, 4))   # 12

# a = {'score': 90}
# getter = operator.itemgetter('score')
# print(getter(a))            # 90
