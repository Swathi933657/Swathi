stack.put_nowait(40)
stack.put_nowait(50)
print(stack.qsize())
