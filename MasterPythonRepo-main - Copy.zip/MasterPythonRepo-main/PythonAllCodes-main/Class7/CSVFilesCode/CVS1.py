# Example 1
import csv

import math as m


mathematics.sqrt(16)
# Example 2
import csv as cssssv

# Example 3
from csv import reader

# Example 4
from csv import writer

# Example 5
from csv import DictReader, DictWriter


class A:
    a1=90
    def add():
        pass



class B(A):
    a2=90    
    def fun():
        pass
     def add():
        pass


bobj = B()
bobj.


obj1 = Sample()

print(obj1.a)
print(obj1.fun())


