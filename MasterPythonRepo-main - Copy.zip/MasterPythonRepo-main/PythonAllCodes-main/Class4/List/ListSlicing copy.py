lst = [10, 20, 30,12,23, 40, 50,60]
# print(lst[1:4])

# print(lst[:3])
# print(lst[2:])
print(lst[::3])
print(lst[::-1])
