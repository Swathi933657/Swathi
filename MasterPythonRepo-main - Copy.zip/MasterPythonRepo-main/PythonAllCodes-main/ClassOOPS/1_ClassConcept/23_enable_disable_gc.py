# How to enable and disable Garbage Collector in our Program
import gc
gc.disable()
gc.enable()
