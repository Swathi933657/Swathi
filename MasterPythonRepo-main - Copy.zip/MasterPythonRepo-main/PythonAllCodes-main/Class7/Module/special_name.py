# The Special Variable __name__
def show():
    print("Module name:", __name__)
show()
