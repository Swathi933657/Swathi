# Introduction to FastAPI

This example demonstrates a minimal FastAPI application.

## How to run

1. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
2. Start the server:
   ```powershell
   uvicorn main:app --reload
   ```
3. Open your browser at http://127.0.0.1:8000

You should see a welcome message from FastAPI.
