# Integer to string
num = 42
str_num = str(num)
print("The number is " + str_num)  # Output: The number is 42

# String to integer
str_value = "100"
int_value = int(str_value)
print(int_value + 50)  # Output: 150

# Float to int
float_value = 5.99
print(int(float_value))  # Output: 5
