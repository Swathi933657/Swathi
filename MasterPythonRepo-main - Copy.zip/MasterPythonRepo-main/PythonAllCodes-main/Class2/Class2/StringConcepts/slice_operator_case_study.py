s = "Programming"
print(s[3:8])    # rammi
print(s[::-1])   # gnimmargorP