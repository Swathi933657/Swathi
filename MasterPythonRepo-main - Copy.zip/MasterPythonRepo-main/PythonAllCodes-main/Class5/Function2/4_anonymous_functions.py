# Anonymous Functions
add = lambda a, b: a + b
print(add(2, 3))

#TODO
#add more exmaples of lambda function
# Example with map
squared = list(map(lambda x: x**2, range(5)))       
print(squared)

