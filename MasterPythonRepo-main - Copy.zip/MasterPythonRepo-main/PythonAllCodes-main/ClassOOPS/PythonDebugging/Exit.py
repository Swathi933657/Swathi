import pdb

def test():
    pdb.set_trace()  # Use 'q' or exit command during debugging
    print("Line after breakpoint")

test()
