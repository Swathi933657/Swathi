from abc import ABC, abstractmethod

class Shape(ABC):
    
    def area(self):
        pass





