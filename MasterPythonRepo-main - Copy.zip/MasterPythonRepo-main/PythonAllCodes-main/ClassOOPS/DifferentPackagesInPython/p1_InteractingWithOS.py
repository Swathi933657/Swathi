import os

# Current directory
print(os.getcwd())

# List files
print(os.listdir())

# Create directory
os.mkdir("test_folder")

# Remove file/folder
# os.remove("file33.txt")
os.rmdir("test_folder")
