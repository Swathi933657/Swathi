# # Factorial using recursion
def factorial(input):
    if input == 0:
        return 1
    return input * factorial(input - 1)


print(factorial(5))


for temp in range(5):
    print(temp)

a=1



    












