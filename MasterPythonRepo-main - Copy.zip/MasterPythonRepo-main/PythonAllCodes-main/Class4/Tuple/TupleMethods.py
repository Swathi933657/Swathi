tup = (1, 2, 2,2, 3)
print(tup.count(2))


# print(tup.count(2))
# print(tup.index(2))

# # Remaining examples
# print(tup.count(10))
# print((5, 5, 5).index(5))
print(('a', 'b', 'c').count('d'))  # returns 0


print((1, 2, 3).index(2))

#TODO 
#cmp function 

#TODO 
#Mathematical operator + and * example for tuple - 119


