import py_compile

py_compile.compile('example.py')
