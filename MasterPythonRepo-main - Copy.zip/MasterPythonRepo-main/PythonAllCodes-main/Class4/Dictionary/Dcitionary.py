# d = {'a': 1, 'b': 2}
# d2 = dict(name='John', age=30)
# d3 = {'x': 100, 'y': 200}
# d4 = dict([('a', 1), ('b', 2)])
# d5 = {1: 'one', 2: 'two'}
# print(d)
# print(d2)
# print(d3)
# print(d4)








tenp = {'a':'1','b':23,'c':3}
print(tenp)

d2 = dict(name='John', age=30)
print(d2)

