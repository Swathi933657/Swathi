lst = [1, 2, 3]
t1 = tuple(lst)
t2 = tuple(['x', 'y'])
t3 = tuple(['a', 'b', 'c'])
t4 = tuple([True, False])
t5 = tuple([])
