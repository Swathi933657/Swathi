def add(self, a, b):
        return a + b



class Calculator:
    u=90
    def ad23(self, a, b):
        return a + b

c = Calculator()
print(c.u)  # 90
add(5, 3) # 8
