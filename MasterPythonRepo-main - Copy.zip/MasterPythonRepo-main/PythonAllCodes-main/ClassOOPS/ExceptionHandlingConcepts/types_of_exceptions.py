# Types of Exceptions
# ValueError, TypeError, ZeroDivisionError, IndexError, etc.
try:
    x = int("abc")
except ValueError:
    print("ValueError")
