# Python's Exception Hierarchy
# BaseException > Exception > ArithmeticError, LookupError, etc.
print(Exception.__mro__)
