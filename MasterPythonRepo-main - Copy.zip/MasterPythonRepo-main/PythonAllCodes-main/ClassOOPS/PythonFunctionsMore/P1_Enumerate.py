# Enumerate adds index to elements when looping
fruits ={'apple', 'banana', 'cherry'}

for index, fruit in enumerate(fruits):
    print(f"{index}: {fruit}")


