# Working with random Module
import random
print(random.randint(1, 10))
print(random.choice(['apple', 'banana', 'cherry']))
print(random.random())
