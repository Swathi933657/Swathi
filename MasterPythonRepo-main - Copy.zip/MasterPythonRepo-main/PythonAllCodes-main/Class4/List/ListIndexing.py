lst = [1,2,3,4,5]
print(lst[0])
print(lst[-1])
print(lst[2])
print(lst[-2])
print(lst[1])



# xyz = "fortune"
# print(str[0])
# print(str[-1])
# print(str[2])
# print(str[-2])
# print(str[1])