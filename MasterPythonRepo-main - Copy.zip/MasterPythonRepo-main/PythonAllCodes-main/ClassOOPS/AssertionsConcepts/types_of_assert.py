# Types of assert Statements
x = 10
assert x == 10
assert x > 0, "x must be positive"
