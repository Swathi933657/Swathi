class Example:
    def show(self):
        print("Public Method")

obj = Example()
obj.show()
