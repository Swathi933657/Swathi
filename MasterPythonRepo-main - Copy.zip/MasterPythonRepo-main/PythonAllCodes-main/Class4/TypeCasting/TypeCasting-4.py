# Taking input from user and converting to integer
user_input = input("Enter a number: ")  # input() returns a string
number = int(user_input)
print("Double of your number is:", number * 2)
