list1 = []
list2 = list()
list3 = [10, 20, 30,40,"fkjkghgfhgjhf"]
list4 = [i for i in range(10)] 
list5 = list('python')
print(list4 )
 

list4 = [i for i in range(15)] 
print(list4)




# temp = [1,2,3]
# temp = list()
# temp = [i for i in range(10)]
# print(temp)

