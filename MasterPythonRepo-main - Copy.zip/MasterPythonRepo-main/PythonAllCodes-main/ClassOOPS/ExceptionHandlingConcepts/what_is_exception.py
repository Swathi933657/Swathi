# What is Exception
# Exception is an event that disrupts normal program flow.
