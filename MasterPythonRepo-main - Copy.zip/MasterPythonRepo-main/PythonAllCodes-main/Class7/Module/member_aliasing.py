# Member Aliasing
from math import sqrt as name
print(name(36))
