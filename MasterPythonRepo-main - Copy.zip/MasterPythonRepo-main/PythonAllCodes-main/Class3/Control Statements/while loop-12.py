# while (1<3):
#     print("*")


a=1 



while(a<10):   # 1,
    print("hi---------",a)
    

    

# print("done")


# #!/usr/bin/python

# var = 1
# while var == 1 :  # This constructs an infinite loop
#    num =input("Enter a number  :")
#    print ("You entered: ", num)

# print ("Good bye!")


#the above one is infinate loop
