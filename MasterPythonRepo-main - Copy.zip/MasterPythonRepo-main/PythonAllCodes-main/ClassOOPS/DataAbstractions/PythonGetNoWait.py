print(stack.get_nowait())
print(stack.get_nowait())
