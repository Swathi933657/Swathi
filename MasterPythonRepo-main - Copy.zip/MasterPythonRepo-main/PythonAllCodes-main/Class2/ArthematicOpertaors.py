# Arthematic operators are + - / %
#datatypes    int , char , string , boolean ,float 
a = 2
b = 21


def add():
    a=a+b
    print(a)    
    return a


class Automobile:
    #constructor    
    def __init__(self):
        print("Automobile created")
    def __init__(self,a):
        print("Automobile created")

    tires="xyz"
    def move():
        print("i am move  function") 
    def move(a):
        print("i am move  function")       

class Car():
    #constructor    

    a=100
    def drifts():
        print(a)        

obj1  = Automobile()
maruthi = Car()

obj1.move()  # I am 
print(obj1.tires)

maruthi.drifts()  #  

maruthi.a= 300

bmw= Car()
obj3.a=1700









 

obj.add()
obj2.

obj.add()
ob2.add()





result = a + b
print("a+b", result)

result = a - b
print("a-b", result)

result = a * b
print("a*b", result)

result = a**b
print("a**b", result)
a=11
b=2
result = a % b  
print("a%b", result)
print(
    "The % symbol in Python is called the Modulo Operator. It returns the remainder of dividing the left hand operand by right hand operand"
)
print("Whats does // does ???????/")
