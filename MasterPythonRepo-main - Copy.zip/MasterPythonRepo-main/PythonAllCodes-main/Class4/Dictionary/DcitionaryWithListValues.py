d = {'fruits': ['apple', 'banana']}
d2 = {'marks': [85, 90, 95]}
d3 = {'letters': list('abc')}
d4 = {'nums': list(range(5))}
d5 = {'data': [1.1, 2.2, 3.3]}
print(d)
print(d2)
print(d3)
print(d4)
print(d5)