from collections import OrderedDict

od = OrderedDict()

od['a'] = 1
od['b'] = 2

print(od)  # OrderedDict([('a', 1), ('b', 2)])
