s = "Python"
print(s[1:4])  # yth
print(s[:2])   # Py
print(s[2:])   # thon