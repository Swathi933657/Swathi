str = "I am some String"
print("I " in str)
print("Z" in str)

print("some " not in str)
print("some " in str)
