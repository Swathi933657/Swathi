# Common Use Cases for Dependencies

This example demonstrates common use cases for dependencies in FastAPI, such as database sessions, authentication, and logging.

- Run the server and access `/users/` to see all dependencies in action.
