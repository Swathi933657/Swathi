s = "I like Java"
print(s.replace("Java", "Python"))  # I like Python