# How to define a Class?
class Student:
    pass

class Human:
    pass



obj = Student()
print(obj)
print(type(obj))
print(id(obj))  # Unique identifier for the object      

obj2 = Human()
print(obj2)
print(type(obj2))
print(id(obj2))  # Unique identifier for the object      
