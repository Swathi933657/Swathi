s = "Python"
print("th" in s)     # True
print("abc" not in s) # True