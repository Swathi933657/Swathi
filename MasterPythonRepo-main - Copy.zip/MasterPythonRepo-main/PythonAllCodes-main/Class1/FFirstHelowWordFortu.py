# print("Heloow World our first program with Data Science")

a=90.89898988
b=89
c=a+b
a="""Today is a good day;
dfdfgdhfgdhfg"""
z= True
print(type(a))
print(a)