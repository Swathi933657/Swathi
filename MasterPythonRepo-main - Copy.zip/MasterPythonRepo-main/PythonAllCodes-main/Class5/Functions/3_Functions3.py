#TODO
#position argument 




def check_even_odd(number=4):
   
    a=90
    if number % 2 == 0:
        print(number, "is Even")
    else:
        print(number, "is Odd")

check_even_odd()







