print("ptython do not have lONG like Java ")
print("Understand + in print and using comma ")
a = 90
b = 90.78787
c = "a"
d = "IamABigWord"
boolean = True
print("boolean value is  ", boolean)

print("a value is  ", a)
print(type(a))
print("a value is " + str(a))   
print(type(a))
print("b value is " + str(b))
print(type(b))
print("c value is " + str(c))
print(type(c))
print("d value is " + str(d))
print(type(d))
print("boolean value is " + str(boolean))
print(type(boolean))

