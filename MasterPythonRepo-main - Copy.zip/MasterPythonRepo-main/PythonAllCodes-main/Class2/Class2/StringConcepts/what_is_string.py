s = "Python is fun"
print(s)