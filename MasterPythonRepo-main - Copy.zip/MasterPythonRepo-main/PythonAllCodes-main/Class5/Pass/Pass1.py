
# def future_function():
#     pass

def add():
    pass





for i in range(5):
    



# class MyClass:
#     pass


# x = 10
# if x > 5:
#     pass
# else:
#     print("x is small")
 
# try:
#     risky_operation()
# except:
#     pass
