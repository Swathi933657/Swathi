try:
    x = 5 / 1
    print(x)
except:
    print("Error occurred")
