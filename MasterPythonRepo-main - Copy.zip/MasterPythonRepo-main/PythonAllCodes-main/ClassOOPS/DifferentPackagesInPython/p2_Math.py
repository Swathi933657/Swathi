import math

print(math.sqrt(16))       # 4.0
print(math.factorial(5))   # 120
print(math.pi)             # 3.1415...
print(math.pow(2, 3))      # 8.0
print(math.ceil(2.3))      # 3
