str = "Hello World"
print(str.startswith("Hello"))  # True
print(str.endswith("World"))    # True