import pdb

def func():
    pdb.set_trace()  # Use 'w' to see stack trace
    print("Inside function")

func()
