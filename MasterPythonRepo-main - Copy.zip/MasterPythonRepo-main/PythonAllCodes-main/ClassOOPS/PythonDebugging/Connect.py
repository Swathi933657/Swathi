import pdb

def test():
    pdb.set_trace()  # Use 'c' to continue execution until next breakpoint
    print("Hello")
    print("World")

test()
