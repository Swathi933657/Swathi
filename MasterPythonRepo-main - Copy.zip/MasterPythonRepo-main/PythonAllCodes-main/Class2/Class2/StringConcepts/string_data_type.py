s = "Hello, World!"
print(type(s))  # <class 'str'>