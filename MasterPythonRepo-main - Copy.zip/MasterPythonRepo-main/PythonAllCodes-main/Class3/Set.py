print("Set is same as List in Java")
print("Insertion order is NOTT preserved")
print("Hetrogenious Object can be aded")
print("Duplicates cannot cannot be added")
print("Growable in Nature")
print("Values shall be enclosed with flower brackets")

print("Mutable in Nature ")

set = {"1", "2", 23, 45.45454}

# print(set[0])
# print(set[-1])
# set[1] = 99909999

print(set)
set.add("newStringValue")
print(set)
set.remove(23)
print("After removing ", set)
