x = int(input("Please enter an integer: "))
print(type(x))


# if x < 0:
#      x = 0
#      print('Negative changed to zero')
#  elif x == 0:w
#      print('Zero')
#  elif x == 1:
#      print('Single')
#  else:
#      print('More')


a=90
if(a==90):
    print("dfgdsghfsdghf")
    



citizen="indidhdvfvan"
age=18
if(citizen=="indian"):
    
    if(age>=18):
        print("eligible")
    
    else:
        print("not greater than 18")
     
else:
    print("not an indian citizen")
print("end of the code")



        
