s = "apple,banana,cherry"
print(s.split(","))   # ['apple', 'banana', 'cherry']