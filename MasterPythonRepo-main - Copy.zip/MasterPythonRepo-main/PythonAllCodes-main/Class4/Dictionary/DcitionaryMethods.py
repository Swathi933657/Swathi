d = {'a': 1, 'b': 2}
print(d.keys())
print(d.values())
print(d.items())
d.update({'c': 3})
d.pop('a')
print(d)



# //oops
# class
# object
# inheritance
# polymorphism
# encapsulation

