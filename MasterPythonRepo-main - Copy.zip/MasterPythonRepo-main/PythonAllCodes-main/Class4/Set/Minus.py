# a = {1, 2, 3}
# b = {2, 3}
# print(a - b)
# print(b - a)
# print(set('hello') - set('world'))
# print({10, 20, 30} - {20})
# print( {20}-{10, 20, 30} )
# print(set([1, 2, 3]) - set([3]))



temp =set(["string1","string2"])
temp2 = set(["string2","string4"])

newTemp =   temp -temp2
print(newTemp)
