# print("List is same as List in Java")
# print("Insertion order is preserved")
# print("Hetrogenious Object can be aded")
# print("Duplicates can be added")
# print("Growable in Nature")
# print("Values shall be enclosed with sqaure brackets")
a=90
list= ["1", "2", 23, 45.45454]
print(list)
print(list[0])
print(list[-2])
list[1] = 99909999
list[2] = 134343

print(list)
list.append("Suraj")
print(list)
list = list * 2
print("printing List after * 2", list)
list.append("Mohan")

print("Before list[4]  action  ",list)
list[4] = "mohan"
print("\n\n\n\n")
print("After Replacing   and chnagig suraj ",list)
# a = 90
# print(a)
# a = 12
# print(a)
