# Creating and Using Dependencies

This example shows how to create and use dependencies in FastAPI using the Depends function.

- Run the server and access `/items/` to see how a dependency injects a query parameter.
