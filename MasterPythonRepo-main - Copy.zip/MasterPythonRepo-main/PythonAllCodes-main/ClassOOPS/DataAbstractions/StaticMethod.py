import math

class Example:
    a=90
    @staticmethod
    def greet():
        print("Hello from static method")
    def add():
        print(90+90)



Example.greet()
