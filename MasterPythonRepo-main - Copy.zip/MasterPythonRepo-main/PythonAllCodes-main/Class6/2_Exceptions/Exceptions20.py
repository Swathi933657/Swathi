try:
    10 / 0
except ZeroDivisionError:
    print("ZeroDivisionError occurred")
