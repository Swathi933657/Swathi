a=90  #global


def add():
    c=7   //local
    print("Addition is ")
    print(c)
    print(a)  #global  

add() 
c=90


class Sample 



# Example 1
import math

print(math.sqrt(49))

# Example 2
import math as temp


temp.sqrt(36)

# Example 3
from module_with_class import trig

# Example 4
from module_with_constants import PI

# Example 5
from math import square
