# Default except Block
try:
    x = 1 / 0
except:
    print("Some error occurred")
