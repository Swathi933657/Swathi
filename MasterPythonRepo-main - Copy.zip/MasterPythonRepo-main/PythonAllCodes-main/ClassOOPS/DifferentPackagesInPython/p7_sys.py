import sys

print(sys.version)         
print(sys.path)            
sys.exit()                 # Exit program
