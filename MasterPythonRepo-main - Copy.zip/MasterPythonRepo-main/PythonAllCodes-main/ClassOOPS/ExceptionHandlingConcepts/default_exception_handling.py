# Default Exception Handing in Python
# If not handled, Python prints error message and stops execution.
x = 1 / 0
