rows = 15
for i in range(1, rows + 1):    # i = 1,2,3,4
    print(' ' * (rows - i) + '*' * (2 * i - 1))     #              * 
                                                    #             ***
                                                    #            *****
                                                    #           *******                


