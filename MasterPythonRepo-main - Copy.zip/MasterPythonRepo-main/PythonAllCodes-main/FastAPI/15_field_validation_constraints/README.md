# Field Validation and Constraints

This example demonstrates how to use min_length, max_length, and regex constraints in Pydantic models.

- Run the server and POST to `/products/` with a JSON body to test validation.
