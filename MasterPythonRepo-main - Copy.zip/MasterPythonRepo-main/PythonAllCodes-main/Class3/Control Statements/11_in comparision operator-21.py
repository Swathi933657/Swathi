fruit="mango"
thing="bat"
print('g'in fruit)
'b' in thing



