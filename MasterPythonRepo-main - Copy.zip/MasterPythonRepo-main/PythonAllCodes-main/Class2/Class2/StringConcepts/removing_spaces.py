s = "  Hello World  "
print(s.strip())      # Hello World
print(s.lstrip())     # Hello World  
print(s.rstrip())     #   Hello World