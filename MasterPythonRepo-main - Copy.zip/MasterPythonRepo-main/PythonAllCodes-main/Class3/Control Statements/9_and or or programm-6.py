a=90
b=8
if(a==90 and b==81):
    print("a is 90 and b is 8")

elif (a==90 and b==71):
    print("a= 90 and b=7")

else:
    print("this is just else")

if(a==901 or b==81):
    print("a is 90 and b is 8")

elif (a==901 or b==7):  
    print("a= 90 and b=7")

else:
    print("this is just else")


    
