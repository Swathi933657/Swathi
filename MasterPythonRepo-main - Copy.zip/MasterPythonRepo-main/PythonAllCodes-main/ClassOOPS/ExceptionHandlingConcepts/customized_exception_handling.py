# Customized Exception Handling by using try-except
try:
    x = 1 / 0
except ZeroDivisionError:
    print("Cannot divide by zero")
