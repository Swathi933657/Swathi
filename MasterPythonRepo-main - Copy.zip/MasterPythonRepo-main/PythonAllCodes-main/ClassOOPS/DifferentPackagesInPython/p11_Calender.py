import calendar

print(calendar.month(2025, 7))
print(calendar.isleap(2024))  # True
