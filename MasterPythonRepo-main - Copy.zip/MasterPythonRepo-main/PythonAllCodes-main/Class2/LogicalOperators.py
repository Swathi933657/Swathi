# Logical OPertors are AND OR NOT
# AND
# T T T
# T F F
# F T F
# F F F

# OR
# T T T
# T F T
# F T T
# F F F

# not
# T F
# F T
a = True
b = False
resultAND = a and b   
resultOR = a or b
if 1==1:
    print("1 is equal to 1")
    print(" result True only")



if resultOR:
    print(" result2 True nfdfhgdfhdagfgonly")

