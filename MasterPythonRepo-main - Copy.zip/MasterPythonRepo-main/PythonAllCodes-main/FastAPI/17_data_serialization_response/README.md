# Data Serialization and Response Customization

This example demonstrates how to serialize data and customize API responses using Pydantic models.

- Run the server and GET `/items/` to see a list of items returned as JSON.
