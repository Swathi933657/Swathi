#add all theory for list page 98 in hard copy 
#Use the pic .. insertion order, immutablilty , duplicate,none 
#comphersion 


a = [1, 2, 3]  #list(range(4))
b = ['apple', 'banana', 'cherry']
c = list(range(5))    # 0,1,2,3,4
d = [x**2 for x in range(4)]     

# e = list('Suraj')
# print(d)


# leanring curve
#creation,accessing,traversing ,funtions verbs ,difference in verbs 
#membership, nested,comphreshion 







# a=90
# str = "monitor"
# # print(a)

# classNineThirty = "suraj"

# a= []
# surajList = ["suraj","deepak","siri",23,"ricky"]
# print(surajList)
# surajList.append("garima")
# print(surajList)
# surajList.insert(1,"salma")
# print(surajList.index(23)) 

# newnumber = int(input("enter number"))
# surajList.append(newnumber)
# print(surajList)

list =[1,2,3]

nameAnything  =[10,2,53,4,15,6,37,8,9,"suraj",10]
print(nameAnything)
print(nameAnything.index("suraj"
                        ))
nameAnything.append("sjhdsgdf")
print(nameAnything)






# numbers.sort()
# print(numbers)
# numbers.reverse()
# print(numbers)
# numbers.clear()
# print("After clearning ",numbers)





# // how can you print list in reverse order
# // how you print list wihtout obj direct ...for or while etc noot print(surajList)



# temp = list() # empty list
# print("before append",temp)   
# temp.append("sirii")
# print(" after append",temp)
# temp.insert


# //  insertion order is preserved
# //  duplicate values are allowed    
# //  heterogeneous values are allowed
# //  mutable