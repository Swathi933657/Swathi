# create a set of integer type
student_id = {112, 114, 116, 118, 115}
print("Student ID:", student_id)

# create a set of string type
vowel_letters = {"a", "e", "i", "o", "u"}
print("Vowel Letters:", vowel_letters)

# create a set of mixed data types
mixed_set = {"Hello", 101, -2, "Bye"}
print("Set of mixed data types:", mixed_set)
