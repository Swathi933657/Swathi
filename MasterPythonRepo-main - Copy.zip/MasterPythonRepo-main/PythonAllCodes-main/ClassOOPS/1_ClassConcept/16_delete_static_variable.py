# How to Delete Static Variables of a Class
class Student:
    school = "ABC School"
del Student.school
