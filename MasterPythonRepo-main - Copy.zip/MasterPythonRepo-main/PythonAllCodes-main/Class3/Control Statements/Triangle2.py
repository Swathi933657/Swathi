rows = 5
for i in range(1, rows + 1):      # 1- 6    rows = 1   i = 1,2,3
    print(' ' * (rows - i) + '*' * i)

# for i in range(1, 10, 3):
#     print(i)
