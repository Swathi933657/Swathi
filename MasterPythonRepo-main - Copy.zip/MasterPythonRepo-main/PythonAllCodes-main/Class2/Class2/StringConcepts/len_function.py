s = "Python"
print(len(s))  # 6