a = {1, 2}
b = {2, 3}
print(a | b)
print(a.union(b))
print({1} | {1, 2, 3})
print(set('ab') | set('bc'))
print(set([1, 2]) | set([3, 4]))
