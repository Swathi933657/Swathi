# Nested Models and Custom Validation

This example shows how to use nested Pydantic models and custom validation logic.

- Run the server and POST to `/customers/` with a JSON body containing addresses.
