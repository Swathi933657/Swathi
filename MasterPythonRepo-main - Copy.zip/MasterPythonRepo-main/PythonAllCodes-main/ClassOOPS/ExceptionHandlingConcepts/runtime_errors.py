# Runtime Errors
# x = 1 / 0  # ZeroDivisionError
