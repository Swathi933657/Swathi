try:
    result = 5 + 5
except:
    print("Error")
else:
    print("Result is", result)
