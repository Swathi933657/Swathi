#TODO
#Dafult Argument 

def repeat_line(a="default", b=2):
    for i in range(b):
        print(a)




repeat_line()
#repaeat_line(2,"sometext")



