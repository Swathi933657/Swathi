import time

print("Start")
time.sleep(2)   # Wait 2 seconds
print("End")

print(time.time())     # Epoch timestamp
