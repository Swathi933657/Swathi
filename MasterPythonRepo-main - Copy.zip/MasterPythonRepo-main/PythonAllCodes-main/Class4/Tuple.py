t = (0, 23, 45, "someValue")
print(t)
print(t[1])
print("One cannot add remove any items from Tuple")
