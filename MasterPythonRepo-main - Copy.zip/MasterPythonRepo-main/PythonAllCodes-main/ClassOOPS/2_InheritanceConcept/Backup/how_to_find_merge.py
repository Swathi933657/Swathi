# How to find Merge?
# Merge is used in C3 linearization for MRO
# Example: See mro(P) by using C3 Algorithm
