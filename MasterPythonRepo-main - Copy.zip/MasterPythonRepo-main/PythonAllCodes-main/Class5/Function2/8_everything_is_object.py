# Everything is an Object
print(type(10))
print(type("hello"))
print(type(lambda x: x))
