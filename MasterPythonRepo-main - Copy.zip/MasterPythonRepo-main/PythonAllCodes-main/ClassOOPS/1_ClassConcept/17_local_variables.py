# Local Variables
class Test:
    def show(self):
        x = 10  # Local variable
        print(x)
