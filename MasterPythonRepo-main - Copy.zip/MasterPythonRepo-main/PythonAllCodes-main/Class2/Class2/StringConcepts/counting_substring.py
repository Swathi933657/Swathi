s = "banana"
print(s.count("a"))   # 3