class Demo:
    @classmethod
    def show(cls):
        print("Class method called")

Demo.show()
