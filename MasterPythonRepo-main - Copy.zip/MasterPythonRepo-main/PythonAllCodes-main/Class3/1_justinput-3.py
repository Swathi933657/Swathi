a=input("enter value for a")
b=input("Enter value for b")
c=a+b
print("c",c)

# a=input("enter value for a")
# print(type(a))
# b=input("Enter value for b")

# a="12"
# b="12"
# print(type(a))
# print(type(b))
# c=a+b
# print("c",c)
