# How to Print Exception Information
try:
    x = 1 / 0
except Exception as e:
    print("Exception info:", e)
