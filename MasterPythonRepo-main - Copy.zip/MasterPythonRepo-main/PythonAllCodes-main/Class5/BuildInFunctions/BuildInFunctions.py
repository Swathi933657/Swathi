print(len("Hellow Old"))
# len()






print(len("OpenAI "))




print(len([1, 2, 3, 4]))



print(len((True, False)))




print(len({1: "a", 2: "b"}))
print(len({10, 20, 30}))
print(len(range(10)))   
print("edge case")    
print(len("  "))  # Edge case: empty string

# # max()
print(max(5, 10))
print(max([1, 4, 7, 2]))
print(max("abcxyz"))
print(max((11, 22, 33)))
print(max([-5, -1, -10]))
print(max({1, 3, 2}))   
print(max({1: "a", 2: "b"}))  # max on dictionary keys  
print(max({"ahmed", "suraj"}))  # max on set elements

   


# # range()
print(list(range(5)))
print(list(range(2, 10)))
print(list(range(1, 11, 2)))
print(list(range(10, 0, -2)))
print(list(range(3, 3)))  # Empty range

# # min()
# print(min(5, 10))
# print(min([1, 4, 7, 2]))
# print(min("abcxyz"))
# print(min((11, 22, 33)))
# print(min([-5, -1, -10]))

# # sum()
print(sum([1, 2, 3, 4]))
print(sum(range(5)))
print(sum((5, 10, 15)))
print(sum([1.5, 2.5, 3.0]))
# print(sum(100))
