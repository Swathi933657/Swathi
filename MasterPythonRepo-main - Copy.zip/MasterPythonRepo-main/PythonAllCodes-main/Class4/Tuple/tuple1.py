# leanring curve
#creation,accessing,traversing ,funtions verbs ,difference in verbs 
#membership, nested,comphreshion 

temp = tuple()
# Example of tuple
temp = (1, 2, 3, 4, 5,6,6,6,"temp","temp")


#actions 

print(temp.count("temp"))

temp.index
#comments 
def add():
    """this is where one can write docs"""
    pass

