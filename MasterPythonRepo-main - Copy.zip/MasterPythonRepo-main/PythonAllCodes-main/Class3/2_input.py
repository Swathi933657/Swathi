print("Start of program")
name=input("Please enter your name  ")
print(name)
print("End of program")

