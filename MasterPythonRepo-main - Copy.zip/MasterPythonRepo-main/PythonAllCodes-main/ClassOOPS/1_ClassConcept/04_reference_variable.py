# What is Reference Variable?
class Student:
    name = "name"
    age = 14  




ajay = Student()
vijay= ajay  # s2 is a reference variable pointing to the same object as s1


ajay.age


