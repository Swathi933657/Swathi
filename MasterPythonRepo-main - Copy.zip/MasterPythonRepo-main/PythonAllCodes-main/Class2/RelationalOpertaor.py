# > <   !=  ==


value1 = 11
value2 = 21

if value1 > value2:
    print("Value1 is greater ")
    print("Value 1 is ", value1, "Value2 is ", value2)


# if value1 < value2:

value1 = 11
value2 = 11
if value1 >= value2:
    print("Value1 is greater or equal ")
    print("Value 1 is ", value1, "Value2 is ", value2)

if value1 <= value2:
    print("Value1 is greater or equal ")
    print("Value 1 is ", value1, "Value2 is ", value2)
