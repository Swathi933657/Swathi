# Inheritance
class Parent:
    def show(self):
        print("Parent method")
class Child(Parent):
    pass
c = Child()
c.show()
