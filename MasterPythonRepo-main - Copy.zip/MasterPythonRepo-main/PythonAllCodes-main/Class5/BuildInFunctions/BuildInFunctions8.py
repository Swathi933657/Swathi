set({1,2,3}) 
a= frozenset([1,2,3,4])
a.

fs1 = frozenset([1, 2, 3, 4])
print(fs1)

fs2 = frozenset("abc")
print(fs2)

fs3 = frozenset((10, 20, 30))
print(fs3)

fs4 = frozenset({100, 200, 300})
print(fs4)

fs5 = frozenset()
print(fs5)
