print(stack.get())
print(stack.get())
