# Various Possibilities of import
import math
from math import sqrt
from math import *
