# Reloading a Module
import importlib
import math
s
ad
sa
ds
d
sa
dsad
importlib.reload(math)
