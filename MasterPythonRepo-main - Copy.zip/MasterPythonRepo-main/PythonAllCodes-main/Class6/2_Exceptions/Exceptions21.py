try:
    print(undefined_variable)
except NameError:
    print("NameError occurred")
