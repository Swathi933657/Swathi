s = "Python is easy "
print(s)
print(s[0])    # P
print(s[-1])   # n