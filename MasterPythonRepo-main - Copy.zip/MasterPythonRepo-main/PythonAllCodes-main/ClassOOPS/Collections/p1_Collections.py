import collections
print(dir(collections))  # Shows all collection classes
