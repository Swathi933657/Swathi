# Example 1
class Car:

    brand = "Toyota"

# Example 2
class Person:
    def speak23(self):
        print("Hello!")

# Example 3
class Dog:
    def bark(self):
        print("Woof!")

# Example 4
class Narayan:
    shyam =89;
    def __init__(self, title):
        self.title = title

# Example 5
class chiatanya:
    ravi=90
    def details(self, model):
        print(f"Laptop model is {model}")
