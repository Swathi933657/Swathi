a="first"
b="second"
a+b
print(a+b)
