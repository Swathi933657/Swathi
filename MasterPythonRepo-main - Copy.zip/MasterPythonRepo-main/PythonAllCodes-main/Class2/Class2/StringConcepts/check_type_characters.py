s = "Python123"
print(s.isalpha())   # False
print(s.isdigit())   # False
print(s.isalnum())   # True
print(" ".isspace()) # True