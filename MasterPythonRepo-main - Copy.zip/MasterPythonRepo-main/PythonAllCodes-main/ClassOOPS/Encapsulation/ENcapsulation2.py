class Example:
    def __init__(self):
        self.value = 100

obj = Example()
print(obj.value)
