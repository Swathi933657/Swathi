rows = 7
for temp in range(7):        # 0-6   temp =0,1,2,3,4,5
    print("*" * temp )







