stack = []
stack.append(1)
stack.append(2)
print(stack.pop())
print(stack)
