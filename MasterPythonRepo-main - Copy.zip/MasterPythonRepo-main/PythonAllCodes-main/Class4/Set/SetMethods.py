s = {1, 2}
s.add(3)
print(s)
s.update([4, 5])
print(s)
s.remove(4)
print(s)
s.discard(10)  # no error
print(s)
s.clear()
print(s)




