# Lambda Function
square = lambda x: x * x
print(square(4))


