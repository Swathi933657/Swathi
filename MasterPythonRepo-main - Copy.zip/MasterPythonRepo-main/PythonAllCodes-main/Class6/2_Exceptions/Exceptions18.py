try:
    [1, 2, 3][10]
except IndexError:
    print("IndexError occurred")
