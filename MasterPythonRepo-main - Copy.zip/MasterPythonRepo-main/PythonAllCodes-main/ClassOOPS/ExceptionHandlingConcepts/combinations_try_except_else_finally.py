# Various possible Combinations of try-except-else-finally
try:
    print("Try")
except:
    print("Except")
else:
    print("Else")
finally:
    print("Finally")
