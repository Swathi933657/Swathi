# Example 1
# t= 23

# class Car:
#     z=787
#     print(z)
#     name ="Ravindra"
#     def add(aa,vv):
#         b=566
#         print(b)
#         return aa+vv
# tharWithAlloyWheels= Car()  #object 
# tharWithAlloyWheels2= Car() 
















# Example 2
# class Person:
#     def __init__(self, name):
#         self.name = name
# alice1 = Person("Alice")
# harish = Person("Harish")

# Example 3
class Dog:
    def bark():
        print("Bark! I am bark function")
    def protects(self):
        print("Bark!  i am function to protect")
teddy = Dog()
teddy.bark()
teddy.protects()
teddy.bark()
# d1.bark()

# # Example 4
# class Book:
#     pass
# b1 = Book()

# Example 5
class Laptop:
    def __init__(self, brand,size):  __name__()
        self.brand = brand
        self.size - size
    
l1 = Laptop("Dell")
l1 = Laptop("GGGG")
print(l1.brand)
