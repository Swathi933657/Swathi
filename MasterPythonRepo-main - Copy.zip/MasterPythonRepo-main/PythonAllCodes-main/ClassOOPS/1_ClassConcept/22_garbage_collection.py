# Garbage Collection
import gc
print(gc.isenabled())
