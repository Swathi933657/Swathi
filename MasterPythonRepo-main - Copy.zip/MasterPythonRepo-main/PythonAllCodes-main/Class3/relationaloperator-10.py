a=90
b=34
if(a>=12):
    print("greater")
elif(a<=12):
    print("not greater")
elif(a!=12):
    print("not greater")
