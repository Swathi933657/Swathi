# Introduction to Pydantic Models

This example shows how to define and use Pydantic models in FastAPI.

- Run the server and POST to `/users/` with a JSON body to see validation in action.
