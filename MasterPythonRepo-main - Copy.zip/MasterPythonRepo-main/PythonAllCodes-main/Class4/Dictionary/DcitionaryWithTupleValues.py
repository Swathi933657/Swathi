d = {'coords': (10, 20)}
d2 = {'rgb': (255, 255, 0)}
d3 = {'version': (3, 8)}
d4 = {'date': (2025, 7, 10)}
d5 = {'grades': ('A', 'B', 'C')}
