import re   
# print(re.match(r'\d+', '7abc'))   
# # print("\n")
# print(re.match(r'\w+', 'Hello123'))
# print("ajhdfgashdfs\tadfagdfgusf")

# print(re.match(r'[A-Z]\w+', 'Python3ajshjdsgasgdasudfgdhsss'))
# print(re.match(r'[a-z]+', 'abcXYZ'))




print(re.match(r'abc', 'abcde'))
#explain this code  in one line

print(re.match(r'^\d+', '123abc'))



print(re.match(r'^\d', '5days'))
print(re.match(r'.+', ''))
#some more explaination of regex
print(re.match(r'\d{3}', '4abc123333'))
print(re.match(r'\d{2,4}', '1abc'))
print(re.match(r'\d{2,4}', '12345abc'))


# x



