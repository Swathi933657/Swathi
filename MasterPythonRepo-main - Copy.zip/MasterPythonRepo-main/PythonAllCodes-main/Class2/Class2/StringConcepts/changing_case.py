s = "Python Programming"
print(s.upper())   # PYTHON PROGRAMMING
print(s.lower())   # python programming
print(s.title())   # Python Programming
print(s.swapcase())# pYTHON pROGRAMMING
#TODO: