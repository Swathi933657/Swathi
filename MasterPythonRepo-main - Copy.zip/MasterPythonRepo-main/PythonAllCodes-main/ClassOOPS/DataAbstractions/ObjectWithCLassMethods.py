class Example:
    data = 10

    @classmethod
    def display(cls):
        print(cls.data)

Example.display()
