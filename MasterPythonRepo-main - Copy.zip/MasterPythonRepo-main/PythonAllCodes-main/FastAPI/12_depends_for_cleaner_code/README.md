# Using Depends for Cleaner Code

This example shows how using Depends makes your FastAPI code cleaner and more maintainable.

- Run the server and access `/secure/` to see dependency injection in action.
