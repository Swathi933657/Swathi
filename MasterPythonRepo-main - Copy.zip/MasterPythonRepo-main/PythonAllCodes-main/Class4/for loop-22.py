#!/usr/bin/python

 for i in range(5):
    print(i)

#0
#1
#2
#3
#4


 # Measure some strings:
 words = ['cat', 'window', 'defenestrate']
 for w in words:
     print(w, len(w))

#cat 3
#window 6
#defenestrate 12



#range([start], stop[, step])

#for i in range(4, 10, 2):
#...     print(i)
#... 
#4
#6
#8


