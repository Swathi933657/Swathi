fruits = ["apple", "banana", "cherry"]
print(", ".join(fruits))  # apple, banana, cherry